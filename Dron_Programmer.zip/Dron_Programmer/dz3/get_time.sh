#!/bin/bash
dz3='/home/yaffil/Dron_Programmer/dz3/'
cd $dz2
while true; do
sys_time=$(date +"%H:%M:%S %d/%m/%Y")
echo "Сейчас по серверу="$sys_time
sleep 5
done
