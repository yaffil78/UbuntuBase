yaffil@yaffil-Ubuntu:~/Downloads$ git config -l
user.name=Yaffil78
user.email=screamer78@yandex.ru
core.editor=nano
