#!/bin/bash
dz2='/home/yaffil/Dron_Programmer/dz2/garbage_file/'
cd $dz2
use=$(df -h | grep '/dev/sda2' | awk '{ print $5}' | sed 's/%//g')
cle=17
echo "use="$use
if [[ $use -ge $cle ]]; then
echo "delete file use="
find -mtime -3 -delete
fi
col=$(ls | wc -l)
let "col += 1"
$(dd if=$dz2"test.garbage" of=$dz2"dop$col""_test.garbage" bs=1M count=90)