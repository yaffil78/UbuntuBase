#!/bin/bash
dz2='/home/yaffil/Dron_Programmer/dz2/garbage_file/'
cd $dz2
#IFS=' '
files=$(find $dz2 -iname "*.mp4" -exec echo {}'"' \;)
files_time=$(find $dz2 -iname "*.mp4" -exec ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 {} \;)
col="${files//[^'"']}"
echo "count Files=""${#col}"
echo "files_time="$files_time
for (( i=1; i<=${#col}; i++ ))
do
param=$i
#echo "param="$param
#echo $files_time | awk '{print $'$param'}'
vid=$(echo $files_time | awk '{print $'$param'}')
vid=${vid%.*}
let vid_all+=vid
#let hour=$vid/3600
#let minut=($vid/60 - $hour*60)
#let second=($vid - $hour*3600 -  $minut*60)
#echo "vid="$vid
#echo "hour="$hour
#echo "minut="$minut
#echo "second="$second
done
echo "vid_all="$vid_all
let hour=$vid_all/3600
let minut=($vid_all/60 - $hour*60)
let second=($vid_all - $hour*3600 -  $minut*60)
printf "FULL TIME = %d:%02d:%02d\n" $hour $minut $second
