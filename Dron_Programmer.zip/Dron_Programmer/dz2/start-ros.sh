#!/bin/bash
source /opt/ros/noetic/setup.bash
roslaunch /home/yaffil/dz2/demo_launch.launch
